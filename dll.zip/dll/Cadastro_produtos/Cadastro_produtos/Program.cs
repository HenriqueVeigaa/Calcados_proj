﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CadastroDeProdutos;

namespace Cadastro_produtos
{

    class Program
    {
        static void Main()
        {
            string connectionString = "Server=localhost;Database=CadastroProdutosDB;Trusted_Connection=True;";
            Prod_repo repository = new Prod_repo(connectionString);

            // Exemplo: Adicionar um produto
            Produto novoProduto = new Produto
            {
                Nome = "Produto Teste",
                Preco = 29.99M,
                Quantidade = 10
            };
            repository.AdicionarProduto(novoProduto);
            Console.WriteLine("Produto adicionado!");

            // Exemplo: Listar produtos
            var produtos = repository.ObterProdutos();
            foreach (var produto in produtos)
            {
                Console.WriteLine($"{produto.Id} - {produto.Nome} - {produto.Preco} - {produto.Quantidade}");
            }
        }
    }

}
